package main.algoritmo;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import main.ConcesIntApplication;
import main.algoritmo.Algoritmov7;
import main.autoManager.*;
import main.interventi.*;
import main.officina.*;

@RunWith(SpringRunner.class) 
@ContextConfiguration(classes=ConcesIntApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class Algoritmov7Test {
	
	@Autowired
	AutoService as;
	@Autowired
	InterventoService is;
	@Autowired
	OfficinaService os;

	@Test
	public void testRunAlgoritmo() {
		AggiungiAuto();
		List<Auto> a =compraAuto();
		List<Intervento> i=inserisciInterventi();
		List<Officina> o=creaOfficine();
		Algoritmov7 algoritmo=new Algoritmov7();
		algoritmo.runAlgoritmo(a, o, i);
		//numero macchine milano
		assertEquals(8, algoritmo.getSchedulazione()[0].numMacchineSuper());
		//numero macchine torino
		assertEquals(9,  algoritmo.getSchedulazione()[1].numMacchineSuper());
		//numero macchine bologna
		assertEquals(8,  algoritmo.getSchedulazione()[2].numMacchineSuper());
		//numero macchine venezia
		assertEquals(1,  algoritmo.getSchedulazione()[3].numMacchineSuper());
		//numero macchine genova
		assertEquals(2,  algoritmo.getSchedulazione()[4].numMacchineSuper());
	}
	
	@Test
	public void testRimuoviPonte() {
		AggiungiAuto();
		List<Auto> a =compraAuto();
		List<Intervento> i=inserisciInterventi();
		List<Officina> o=creaOfficine();
		Algoritmov7 algoritmo=new Algoritmov7();
		algoritmo.runAlgoritmo(a, o, i);
		//numero di slot nel ponte 3
		assertEquals(3, algoritmo.getSchedulazione()[0].getPonte(3).size);
		//eliminazione di uno slot nel ponte 3 (removeNodo parte a contare da 0)
		algoritmo.getSchedulazione()[0].removeNodo(2, 1);
		//numero di slot nel ponte 3 dopo eliminazione
		assertEquals(2, algoritmo.getSchedulazione()[0].getPonte(3).size);
	}

	private List<Officina> creaOfficine() {
		List<Officina> o=new ArrayList<>();
		
		Officina b=new Officina(Posizione.TORINO,10,4);
		Officina c=new Officina(Posizione.BOLOGNA,10,3);
		Officina a=new Officina(Posizione.MILANO,13,4);
		Officina e=new Officina(Posizione.GENOVA,3,2);
		Officina d=new Officina(Posizione.VENEZIA,2,1);
		o.add(c);
		o.add(b);
		o.add(a);
		o.add(e);
		o.add(d);
		o=os.saveAll(o);
		return o;
	}

	private List<Intervento> inserisciInterventi() {
		List<Intervento> il=new ArrayList<>();
		idIntervento id=new idIntervento("targa0","lavoro");
		Intervento i=new Intervento(id,90,false);
		il.add(i);
		
		id=new idIntervento("targa0","lavoro2");
		i=new Intervento(id,90,false);
		il.add(i);
		
		id=new idIntervento("targa0","lavoro3");
		i=new Intervento(id,60,false);
		il.add(i);
		
		id=new idIntervento("targa1","lavoro");
		i=new Intervento(id,60,false);
		il.add(i);
		
		id=new idIntervento("targa1","lavoro2");
		i=new Intervento(id,90,false);
		il.add(i);
		
		id=new idIntervento("targa2","lavoro");
		i=new Intervento(id,120,false);
		il.add(i);
		
		id=new idIntervento("targa3","lavoro");
		i=new Intervento(id,30,false);
		il.add(i);
		
		id=new idIntervento("targa3","lavoro2");
		i=new Intervento(id,30,false);
		il.add(i);
		
		id=new idIntervento("targa3","lavoro3");
		i=new Intervento(id,30,false);
		il.add(i);
		
		id=new idIntervento("targa3","lavoro4");
		i=new Intervento(id,20,false);
		il.add(i);
		
		id=new idIntervento("targa4","lavoro");
		i=new Intervento(id,60,false);
		il.add(i);
		
		id=new idIntervento("targa5","lavoro");
		i=new Intervento(id,10,false);
		il.add(i);
		
		id=new idIntervento("targa5","lavoro2");
		i=new Intervento(id,30,false);
		il.add(i);
		
		id=new idIntervento("targa6","lavoro");
		i=new Intervento(id,180,false);
		il.add(i);
		
		id=new idIntervento("targa7","lavoro");
		i=new Intervento(id,90,false);
		il.add(i);
		
		id=new idIntervento("targa7","lavoro2");
		i=new Intervento(id,60,false);
		il.add(i);
		
		id=new idIntervento("targa8","lavoro");
		i=new Intervento(id,100,false);
		il.add(i);
		
		id=new idIntervento("targa8","lavoro2");
		i=new Intervento(id,100,false);
		il.add(i);
		
		id=new idIntervento("targa9","lavoro");
		i=new Intervento(id,120,false);
		il.add(i);
		
		id=new idIntervento("targa9","lavoro2");
		i=new Intervento(id,40,false);
		il.add(i);
		
		id=new idIntervento("targa10","lavoro2");
		i=new Intervento(id,240,false);
		il.add(i);
		id=new idIntervento("targa11","lavoro2");
		i=new Intervento(id,60,false);
		il.add(i);
		id=new idIntervento("targa12","lavoro2");
		i=new Intervento(id,60,false);
		il.add(i);
		id=new idIntervento("targa13","lavoro2");
		i=new Intervento(id,60,false);
		il.add(i);
		id=new idIntervento("targa14","lavoro2");
		i=new Intervento(id,120,false);
		il.add(i);
		id=new idIntervento("targa15","lavoro2");
		i=new Intervento(id,90,false);
		il.add(i);
		id=new idIntervento("targa16","lavoro2");
		i=new Intervento(id,90,false);
		il.add(i);
		id=new idIntervento("targa17","lavoro2");
		i=new Intervento(id,600,false);
		il.add(i);
		id=new idIntervento("targa18","lavoro2");
		i=new Intervento(id,30,false);
		il.add(i);
		id=new idIntervento("targa19","lavoro2");
		i=new Intervento(id,60,false);
		il.add(i);
		id=new idIntervento("targa20","lavoro2");
		i=new Intervento(id,10,false);
		il.add(i);
		id=new idIntervento("targa21","lavoro2");
		i=new Intervento(id,60,false);
		il.add(i);
		id=new idIntervento("targa22","lavoro2");
		i=new Intervento(id,10,false);
		il.add(i);
		id=new idIntervento("targa23","lavoro2");
		i=new Intervento(id,80,false);
		il.add(i);
		id=new idIntervento("targa24","lavoro2");
		i=new Intervento(id,150,false);
		il.add(i);
		id=new idIntervento("targa25","lavoro2");
		i=new Intervento(id,220,false);
		il.add(i);
		id=new idIntervento("targa26","lavoro2");
		i=new Intervento(id,100,false);
		il.add(i);
		id=new idIntervento("targa27","lavoro2");
		i=new Intervento(id,30,false);
		il.add(i);

		il=is.saveAll(il);
		return il;
		
	}

	private List<Auto> compraAuto() {
		List<Auto> c=new ArrayList<>();
		Auto b=as.CompraAuto("targa0", "a", "2022-02-02", "2022-01-24", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa9", "a", "2022-02-02", "2022-02-04", Posizione.MILANO);
		c.add(b);
		b=as.CompraAuto("targa1", "a", "2022-02-02", "2022-01-25", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa24", "a", "2022-02-02", "2022-02-19", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa2", "a", "2022-02-02", "2022-01-26", Posizione.MILANO);
		c.add(b);
		b=as.CompraAuto("targa3", "a", "2022-02-02", "2022-01-27", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa5", "a", "2022-02-02", "2022-01-29", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa6", "a", "2022-02-02", "2022-02-01", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa7", "a", "2022-02-02", "2022-02-02", Posizione.GENOVA);
		c.add(b);
		b=as.CompraAuto("targa15", "a", "2022-02-02", "2022-02-10", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa8", "a", "2022-02-02", "2022-02-03", Posizione.GENOVA);
		c.add(b);
		b=as.CompraAuto("targa10", "a", "2022-02-02", "2022-02-05", Posizione.MILANO);
		c.add(b);
		b=as.CompraAuto("targa12", "a", "2022-02-02", "2022-02-07", Posizione.GENOVA);
		c.add(b);
		b=as.CompraAuto("targa13", "a", "2022-02-02", "2022-02-08", Posizione.VENEZIA);
		c.add(b);
		b=as.CompraAuto("targa14", "a", "2022-02-02", "2022-02-09", Posizione.MILANO);
		c.add(b);
		b=as.CompraAuto("targa16", "a", "2022-02-02", "2022-02-11", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa17", "a", "2022-02-02", "2022-02-12", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa19", "a", "2022-02-02", "2022-02-14", Posizione.MILANO);
		c.add(b);
		b=as.CompraAuto("targa20", "a", "2022-02-02", "2022-02-15", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa21", "a", "2022-02-02", "2022-02-16", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa4", "a", "2022-02-02", "2022-01-28", Posizione.MILANO);
		c.add(b);
		b=as.CompraAuto("targa22", "a", "2022-02-02", "2022-02-17", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa23", "a", "2022-02-02", "2022-02-18", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa11", "a", "2022-02-02", "2022-02-06", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa25", "a", "2022-02-02", "2022-02-20", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa18", "a", "2022-02-02", "2022-02-13", Posizione.TORINO);
		c.add(b);
		b=as.CompraAuto("targa26", "a", "2022-02-02", "2022-02-21", Posizione.BOLOGNA);
		c.add(b);
		b=as.CompraAuto("targa27", "a", "2022-02-02", "2022-02-22", Posizione.TORINO);
		c.add(b);
				
		return  c;
	}

	private void AggiungiAuto() {
		
		List<Auto> a=new ArrayList<>();
		
		Auto auto=new Auto("targa0","234456","concessionaria","Fiat","Panda",Posizione.TORINO);
		a.add(auto);
		
		 auto=new Auto("targa1","234457","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa2","234458","concessionaria","Fiat","Panda",Posizione.VENEZIA);
		a.add(auto);
		
		auto=new Auto("targa3","234459","concessionaria","Fiat","Panda",Posizione.VENEZIA);
		a.add(auto);
		
		auto=new Auto("targa4","234451","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa5","234452","concessionaria","Fiat","Panda",Posizione.GENOVA);
		a.add(auto);
		
		auto=new Auto("targa6","234453","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa7","234454","concessionaria","Fiat","Panda",Posizione.TORINO);
		a.add(auto);
		
		auto=new Auto("targa8","234455","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa9","2344565","concessionaria","Fiat","Panda",Posizione.TORINO);
		a.add(auto);
		
		auto=new Auto("targa10","334456","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa11","3344565","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa12","3R44565","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa13","34344565","concessionaria","Fiat","Panda",Posizione.VENEZIA);
		a.add(auto);
		
		auto=new Auto("targa14","3354565","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa15","3344065","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa16","3444565","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa17","3844565","concessionaria","Fiat","Panda",Posizione.TORINO);
		a.add(auto);
		
		auto=new Auto("targa18","3394565","concessionaria","Fiat","Panda",Posizione.GENOVA);
		a.add(auto);
		
		auto=new Auto("targa19","3340565","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa20","3344065","concessionaria","Fiat","Panda",Posizione.MILANO);
		a.add(auto);
		
		auto=new Auto("targa21","3k344065","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa22","35","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa23","4065","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa24","44065","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa25","365","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		a.add(auto);
		
		auto=new Auto("targa26","33440","concessionaria","Fiat","Panda",Posizione.GENOVA);
		a.add(auto);
		
		auto=new Auto("targa27","33465","concessionaria","Fiat","Panda",Posizione.GENOVA);
		a.add(auto);
		
		as.saveAll(a);
		
	}

	

}