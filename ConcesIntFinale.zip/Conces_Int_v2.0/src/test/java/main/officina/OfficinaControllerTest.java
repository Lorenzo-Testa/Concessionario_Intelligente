package main.officina;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import main.ConcesIntApplication;

@RunWith(SpringRunner.class) 
@ContextConfiguration(classes=ConcesIntApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class OfficinaControllerTest {
	
	@Autowired
	OfficinaController oc;
	
	@Autowired
	OfficinaRepository or;
	
	@Before
	public void test() {
		OfficinaOggetto o = new OfficinaOggetto(Posizione.BOLOGNA, 0, 20, 4);
		oc.aggiungiOfficina(o);
		o = new OfficinaOggetto(Posizione.MILANO, 0, 300, 2);
		oc.aggiungiOfficina(o);
	}

	@Test
	public void testAggiungi() {
		oc.aggiungi(Posizione.BOLOGNA, 30);
		assertEquals(30, oc.findAll().get(0).getTempoincoda());
	}

	@Test
	public void testRimuovi() {
		oc.rimuovi(Posizione.BOLOGNA, 10);
		assertEquals(-10, oc.findAll().get(0).getTempoincoda());
	}

	@Test
	public void testNumeroPonti() {
		assertEquals(4, oc.NumeroPonti(Posizione.BOLOGNA));
		assertEquals(2, oc.NumeroPonti(Posizione.MILANO));
	}

	@Test
	public void testFindAll() {
		assertEquals(2, oc.findAll().size());
	}

}
