package main.interventi;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.server.ResponseStatusException;

import main.ConcesIntApplication;


@RunWith(SpringRunner.class) 
@ContextConfiguration(classes=ConcesIntApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class InterventoControllerTest {
	
	@Autowired
	InterventoController ic;
	
	@Autowired
	InterventoRepository ir;
	
	@Before
	public void test() {
		idIntervento id=new idIntervento("targa","lavoro");
		InterventoOggetto a= new InterventoOggetto(id,false,100);
		ic.inserisciIntervento(a);
		id=new idIntervento("targa","lavoro1");
		a= new InterventoOggetto(id,false,200);
		ic.inserisciIntervento(a);
	}

	@Test
	public void testInserisciIntervento() {
		idIntervento id=new idIntervento("targa2","lavoro2");
		InterventoOggetto a= new InterventoOggetto(id,false,100);
		ic.inserisciIntervento(a);
		assertEquals(3,ir.count());
	}
	
	@Test
	public void testInterventoTerminato() {
		idIntervento id=new idIntervento("targa","lavoro");
		ic.interventoTerminato("targa","lavoro");
		assertTrue(ir.findById(id).get().isEseguito());
	}
	
	@Test(expected = ResponseStatusException.class)
	public void testExpInterventoTerminato() {
		ic.interventoTerminato("targa465","lavoro2");
		}
	
	@Test
	public void testTempoLavorazioneAuto() {
		assertEquals(300, ic.tempoLavorazioneAuto("targa"));
	}
	
	@Test
	public void testFindAll() {
		assertEquals(2, ic.findAll().size());
	}
	
	@Test
	public void testFindAllByTargaAndEseguito() {
		assertEquals(2, ic.findAllByTargaAndEseguito("targa", false).size());
		ic.interventoTerminato("targa", "lavoro");
		assertEquals(1, ic.findAllByTargaAndEseguito("targa", false).size());
		assertEquals(1, ic.findAllByTargaAndEseguito("targa", true).size());
	}

	

}
