package main.interventi;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.server.ResponseStatusException;

import main.ConcesIntApplication;


@RunWith(SpringRunner.class) 
@ContextConfiguration(classes=ConcesIntApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class InterventoControllerTest {
	
	@Autowired
	InterventoController ic;
	
	@Autowired
	InterventoRepository ir;
	
	@Before
	public void test() {
		idIntervento id=new idIntervento("targa","lavoro");
		InterventoOggetto a= new InterventoOggetto(id,false,100);
		ic.inserisciIntervento(a);
	}

	@Test
	public void testInserisciIntervento() {
		idIntervento id=new idIntervento("targa2","lavoro2");
		InterventoOggetto a= new InterventoOggetto(id,false,100);
		ic.inserisciIntervento(a);
		assertEquals(2,ir.count());
	}
	
	@Test
	public void testInterventoTerminato() {
		idIntervento id=new idIntervento("targa","lavoro");
		ic.interventoTerminato("targa","lavoro");
		assertTrue(ir.findById(id).get().isEseguito());
	}
	
	@Test(expected = ResponseStatusException.class)
	public void testExpInterventoTerminato() {
		ic.interventoTerminato("targa465","lavoro2");
		}
	

	

}
