package main.autoManager;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import main.ConcesIntApplication;
import main.officina.Officina;
import main.officina.OfficinaRepository;
import main.officina.Posizione;

@RunWith(SpringRunner.class) 
@ContextConfiguration(classes=ConcesIntApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class AutoControllerTest {
	
	@Autowired
	AutoController ac;
	
	@Autowired
	AutoRepository ar;
	
	@Autowired
	OfficinaRepository or;
	
	@Before
	public void test() {
		Officina oMi = new Officina(Posizione.MILANO, 50, 4);
		Officina oBo = new Officina(Posizione.BOLOGNA, 150, 3);
		Officina oGe = new Officina(Posizione.GENOVA, 30, 2);
		Officina oVe = new Officina(Posizione.VENEZIA, 230, 5);
		or.save(oMi);
		or.save(oBo);
		or.save(oGe);
		or.save(oVe);
		AutoOggetto auto=new AutoOggetto("bb000bb","12345","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("ee000ee","56789","concessionaria","Fiat","500",Posizione.GENOVA);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("ff000ff","67890","concessionaria","Nissan","Micra",Posizione.MILANO);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("aa000aa","36451","concessionaria","Kia","Ceed",Posizione.VENEZIA);
		ac.inserisciAuto(auto);
	}

	@Test
	public void testCompraAuto() {
		ac.CompraAuto("bb000bb", "Paolo", "2022-01-20", "2022-06-12", Posizione.VENEZIA);
		ac.CompraAuto("ee000ee", "Mario", "2021-12-21", "2022-05-10", Posizione.GENOVA);
		assertTrue(ar.findById("bb000bb").get().isVenduta());
		assertTrue(ar.findById("ee000ee").get().isVenduta());
		assertFalse(ar.findById("ff000ff").get().isVenduta());
		assertFalse(ar.findById("aa000aa").get().isVenduta());
	}
	

	@Test
	public void testInserisciAuto() {
		assertEquals(4,ar.count());
		AutoOggetto auto=new AutoOggetto("bb000bb","234456","concessionaria","Fiat","Panda",Posizione.MILANO);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("cc000cc","34567","concessionaria","Nissan","Qashqai",Posizione.BOLOGNA);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("dd000dd","45678","concessionaria","Audi","gamma s",Posizione.GENOVA);
		ac.inserisciAuto(auto);
		assertEquals(6,ar.count());
	}	
	
	@Test
	public void testFindByTarga() {
		assertEquals("bb000bb", ac.findByTarga("bb000bb").getTarga());
	}
	
//	@Test
//	public void testCambiaStatoAuto() {
//		assertEquals(Stato.TRASPORTO1, ac.cambiaStatoAuto("aa000aa", Stato.TRASPORTO1, Posizione.VENEZIA).getStato());
//	}
	
	@Test
	public void testFindAll() {
		assertEquals(4, ac.findAll().size());
	}
	
	@Test
	public void testRimuoviAuto() {
		ac.RimuoviAuto("ff000ff");
		assertEquals(3, ac.findAll().size());
	}
	
	@Test
	public void testFindAllByPosizione() {
		assertEquals(1, ac.findAllByPosizione(Posizione.BOLOGNA).size());
		assertEquals(1, ac.findAllByPosizione(Posizione.GENOVA).size());
		assertEquals(1, ac.findAllByPosizione(Posizione.MILANO).size());
		assertEquals(1, ac.findAllByPosizione(Posizione.VENEZIA).size());
		assertEquals(0, ac.findAllByPosizione(Posizione.TORINO).size());
	}
	
	@Test
	public void testFindAllByVenduta() {
		assertEquals(4, ac.findAllByVenduta(false).size());
		ac.CompraAuto("bb000bb", "Paolo", "2022-01-20", "2022-06-12", Posizione.VENEZIA);
		assertEquals(1, ac.findAllByVenduta(true).size());
	}
	
	@Test
	public void testFindAllByPosizioneAndVenduto() {
		assertEquals(1, ac.findAllByPosizioneAndVenduto(Posizione.BOLOGNA, false).size());
		assertEquals(1, ac.findAllByPosizioneAndVenduto(Posizione.GENOVA, false).size());
		assertEquals(1, ac.findAllByPosizioneAndVenduto(Posizione.MILANO, false).size());
		assertEquals(0, ac.findAllByPosizioneAndVenduto(Posizione.TORINO, false).size());
		assertEquals(1, ac.findAllByPosizioneAndVenduto(Posizione.VENEZIA, false).size());
		ac.CompraAuto("bb000bb", "Paolo", "2022-01-20", "2022-06-12", Posizione.VENEZIA);
		assertEquals(0, ac.findAllByPosizioneAndVenduto(Posizione.BOLOGNA, false).size());
		assertEquals(1, ac.findAllByPosizioneAndVenduto(Posizione.BOLOGNA, true).size());
	}

}
