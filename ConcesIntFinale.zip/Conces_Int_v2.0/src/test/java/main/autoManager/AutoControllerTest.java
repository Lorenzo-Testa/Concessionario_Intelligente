package main.autoManager;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import main.ConcesIntApplication;
import main.autoManager.AutoController;
import main.autoManager.AutoOggetto;
import main.autoManager.AutoRepository;
import main.officina.Officina;
import main.officina.OfficinaOggetto;
import main.officina.OfficinaRepository;
import main.officina.Posizione;

@RunWith(SpringRunner.class) 
@ContextConfiguration(classes=ConcesIntApplication.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class AutoControllerTest {
	
	@Autowired
	AutoController ac;
	
	@Autowired
	AutoRepository ar;
	
	@Autowired
	OfficinaRepository or;

	@Test
	public void testCompraAuto() {
		Officina oMi = new Officina(Posizione.MILANO, 50, 4);
		Officina oBo = new Officina(Posizione.BOLOGNA, 50, 4);
		Officina oGe = new Officina(Posizione.GENOVA, 50, 4);
		Officina oVe = new Officina(Posizione.VENEZIA, 50, 4);
		or.save(oMi);
		or.save(oBo);
		or.save(oGe);
		or.save(oVe);
		AutoOggetto auto=new AutoOggetto("bb000bb","12345","concessionaria","Fiat","Panda",Posizione.BOLOGNA);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("ee000ee","56789","concessionaria","Fiat","500",Posizione.GENOVA);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("ff000ff","67890","concessionaria","Nissan","Micra",Posizione.MILANO);
		ac.inserisciAuto(auto);
		ac.CompraAuto("bb000bb", "Paolo", "2022-01-20", "2022-06-12", Posizione.VENEZIA);
		ac.CompraAuto("ee000ee", "Mario", "2021-12-21", "2022-05-10", Posizione.VENEZIA);
		ac.CompraAuto("ff000ff", "Mario", "2021-12-21", "2022-05-10", Posizione.MILANO);
		assertTrue(ar.findById("bb000bb").get().isVenduta());
		assertTrue(ar.findById("ee000ee").get().isVenduta());
		assertTrue(ar.findById("ff000ff").get().isVenduta());
		
	}
	

	@Test
	public void testInserisciAuto() {
		Officina oMi = new Officina(Posizione.MILANO, 50, 4);
		Officina oTo = new Officina(Posizione.TORINO, 50, 4);
		or.save(oMi);
		or.save(oTo);
		AutoOggetto auto=new AutoOggetto("bb000bb","234456","concessionaria","Fiat","Panda",Posizione.MILANO);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("cc000cc","34567","concessionaria","Nissan","Qashqai",Posizione.TORINO);
		ac.inserisciAuto(auto);
		auto=new AutoOggetto("dd000dd","45678","concessionaria","Audi","gamma s",Posizione.TORINO);
		ac.inserisciAuto(auto);
		assertEquals(3,ar.count());
	}

	

}
