package main.autoManager;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

import main.officina.Posizione;

@Entity
public class Auto  {
	
	
	@Id 
	private String targa;

	@Column(nullable = false)
	private String telaio;
	
	@Column(nullable = false)
	private String proprietario;

	@Column(nullable = false)
	private String marca;

	@Column(nullable = false)
	private String modello;
	
	@Column(nullable = true)
	private String dataconsegna;
	
	@Column(nullable = true)
	private String datavendita;
	
	@Column(nullable = false)
	private boolean venduta;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Stato stato;

	@Enumerated(EnumType.STRING)
	@Column(nullable = false)
	private Posizione concprovenienza;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = true)
	private Posizione conclavorazione;
	
	@Enumerated(EnumType.STRING)
	@Column(nullable = true)
	private Posizione concarrivo;
	
	Auto(){}
	
	public Auto(String targa,String telaio,String p,String marca,String modello,Posizione conc) 
	{
		super();
		this.targa=targa;
		this.telaio=telaio;
		this.proprietario=p;
		this.marca=marca;
		this.modello=modello;
		this.dataconsegna=null;
		this.datavendita=null;
		this.venduta=false;
		this.stato=Stato.NONSCHEDULATO;
		this.concprovenienza=conc;
		this.conclavorazione=null;
		this.concarrivo=null;
		
	}

	

	public String getTarga() {
		return targa;
	}

	public void setTarga(String targa) {
		this.targa = targa;
	}

	public String getTelaio() {
		return telaio;
	}

	public void setTelaio(String telaio) {
		this.telaio = telaio;
	}

	public String getProprietario() {
		return proprietario;
	}

	public void setProprietario(String proprietario) {
		this.proprietario = proprietario;
	}
	
	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModello() {
		return modello;
	}

	public void setModello(String modello) {
		this.modello = modello;
	}

	public String getDataconsegna() {
		return dataconsegna;
	}

	public void setDataconsegna(String dataconsegna) {
		this.dataconsegna = dataconsegna;
	}

	public String getDatavendita() {
		return datavendita;
	}

	public void setDatavendita(String datavendita) {
		this.datavendita = datavendita;
	}

	public boolean isVenduta() {
		return venduta;
	}

	public void setVenduta(boolean venduta) {
		this.venduta = venduta;
	}

	public Posizione getConcprovenienza() {
		return concprovenienza;
	}

	public void setConcprovenienza(Posizione concprovenienza) {
		this.concprovenienza = concprovenienza;
	}

	public Posizione getConclavorazione() {
		return conclavorazione;
	}

	public void setConclavorazione(Posizione conxlavorazione) {
		this.conclavorazione = conxlavorazione;
	}

	public Posizione getConcarrivo() {
		return concarrivo;
	}

	public void setConcarrivo(Posizione arrivo) {
		this.concarrivo = arrivo;
	}
	
	public Stato getStato() {
		return stato;
	}

	public void setStato(Stato stato) {
		this.stato = stato;
	}

	public int compareTo(Auto a) {
		return this.compareTo(a);
	}
	
	/**
	 * trova dove si trova attualmente l'auto
	 * @param auto auto da trovare
	 * @return Posizione attuale auto
	 */
	public Posizione trovaPosizione() {
		switch(stato) {
		case NONSCHEDULATO:
			return this.getConcprovenienza();
		case TRASPORTO1:
			return this.getConclavorazione();
		case INCODA:
			return this.getConclavorazione();
		case INLAVORAZIONE:
			return this.getConclavorazione();
		case TRASPORTO2:
			return this.getConcarrivo();
		case FINITO:
			return this.getConcarrivo();
		case SCHEDULATO:
			return this.getConcprovenienza();
		default :
			return null;
		
		}
	}
	
	@Override
	public String toString() {
		String s="";
		s+=this.targa+" - "+this.stato+"\n";
		return s;
	}
	
	/**
	 * 
	 * @return restituisce la stringa " targa | marca | modello  "
	 */
	public String TargaMarcaModello() {
		String s="";
		s+=this.targa+" | "+this.marca+" | "+this.modello+"\n";
		return s;
	}
	
	
}


	
	


