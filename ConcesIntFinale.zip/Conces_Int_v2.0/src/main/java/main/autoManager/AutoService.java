package main.autoManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import main.interventi.InterventoService;
import main.officina.OfficinaService;
import main.officina.Posizione;

@Service
public class AutoService {

	@Autowired
	private AutoRepository ar;
	@Autowired
	private OfficinaService os;
	@Autowired
	private InterventoService is;

	public AutoService(AutoRepository auto) {
		this.ar = auto;
	}

	/**
	 * aggiunge un nuova auto nella tabella
	 * 
	 * @param nuovaAuto entita da aggiungere
	 * @return entita aggiunta richiama officinaService.aggiungi --> incrementa di 1
	 *         il valore delle auto presenti nell'officina
	 */
	public Auto inserisciAuto(Auto nuovaAuto) {
		os.aggiungi(nuovaAuto.getConcprovenienza(), 0);
		return ar.save(nuovaAuto);
	}

	/**
	 * quando un auto viene comprata l'algoritmo viene lanciato per ottimizzare la
	 * consegna
	 * 
	 * @param targa
	 * @param proprietario
	 * @param datavendita
	 * @param dataconsegna
	 * @param concessionarioconsegna
	 */
	public Auto CompraAuto(String targa, String proprietario, String datavendita, String dataconsegna,
			Posizione concessionarioconsegna) {
		Optional<Auto> a = ar.findById(targa);
		if (!a.isPresent())
			new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
		if (a.get().isVenduta())
			new Exception("L'auto è già stata venduta");
		a.get().setDataconsegna(dataconsegna);
		a.get().setDatavendita(datavendita);
		a.get().setVenduta(true);
		a.get().setProprietario(proprietario);
		a.get().setConcarrivo(concessionarioconsegna);
		Auto b = ar.save(a.get());
		return b;
		// TO-DO LANCIA ALGORITMO
	}

	/**
	 * restituisce l'auto con quella targa
	 * 
	 * @param Targa targa dell'auto
	 * @return auto
	 */
	public Auto findByTarga(String Targa) {
		Optional<Auto> a = ar.findById(Targa);
		return a.get();

	}

	/**
	 * rimuove un auto dalla tabella
	 * 
	 * @param targa targa dell'auto da rimuovere lancia
	 *              officinaService.rimuovi-->decrementa di 1 il valore delle auto
	 *              presenti nell'officina
	 */
	public void RimuoviAuto(String targa) {
		Optional<Auto> a = ar.findById(targa);
		if (!a.isPresent())
			new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
		os.rimuovi(a.get().trovaPosizione(), 0);
		// is.RimuoviInterventi(targa);
		ar.delete(a.get());
	}

	/**
	 * chiamata dopo che l'algoritmo finisce di girare.
	 * 
	 * @param targa             per identificare l'auto
	 * @param concessionariolav concessionario in cui verrà lavorata richiama
	 *                          officinaservice.aggiungi-->incrementa di 1 il valore
	 *                          delle auto presenti nell'offcina di arrivo richiama
	 *                          officinaservice.rimuovi-->decrementa di 1 il valore
	 *                          delle auto presenti nell'officina di partenza
	 *                          richiama
	 *                          InterventoService.officinalavorazione-->setta la
	 *                          lavorazione nell'officina stabilita a tutti gli
	 *                          interventi
	 */
	public void ConcessionarioDiLavorazioneAuto(String targa, Posizione concessionariolav) {
		Optional<Auto> a = ar.findById(targa);
		if (!a.isPresent())
			new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
		a.get().setConclavorazione(concessionariolav);
		is.officinaLavorazione(targa, concessionariolav);
		ar.save(a.get());

	}

	public void saveAll(List<Auto> a) {
		ar.saveAll(a);

	}

	public Auto cambiaStatoAuto(String targa, Stato s, Posizione p) {
		Optional<Auto> a = ar.findById(targa);
		if (!a.isPresent()) {
			new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
			return null;
		}

		else {
			if (a.get().trovaPosizione() != p) {
				new Exception("non puoi cambiare lo stato di un'auto non presente nel tuo concessionario");
				return null;
			}

			else {
				os.rimuovi(p, 0);
				a.get().setStato(s);
				os.aggiungi(a.get().trovaPosizione(), 0);
				ar.save(a.get());
				return a.get();
			}
		}
	}

	public List<Auto> findAll() {
		return (List<Auto>) ar.findAll();

	}

	public List<Auto> findAllByPosizione(Posizione p, List<Auto> listaAuto) {
		List<Auto> autoperposizione = new ArrayList<Auto>();

		for (int i = 0; i < listaAuto.size(); i++) {

			if (listaAuto.get(i).trovaPosizione() == p)
				autoperposizione.add(listaAuto.get(i));
		}
		return autoperposizione;
	}

	public List<Auto> findAllByVenduta(boolean b) {
		
		return  ar.findAllByVenduta(b);
		
		
	}

	public List<Auto> findAllByposioneAndVenduta(Posizione p, boolean b,List<Auto> listaAuto) {
		List<Auto> autoperposizione = new ArrayList<Auto>();

		for (int i = 0; i < listaAuto.size(); i++) {

			if (listaAuto.get(i).trovaPosizione() == p && listaAuto.get(i).isVenduta() == b)
				autoperposizione.add(listaAuto.get(i));
		}
		return autoperposizione;
	}
		
}


