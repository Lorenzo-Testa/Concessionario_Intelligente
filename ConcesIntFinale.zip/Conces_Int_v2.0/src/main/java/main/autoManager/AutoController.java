package main.autoManager;


import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import main.officina.Posizione;

@RestController
public class AutoController{

	@Autowired
	private AutoService as;
	
	public AutoController(AutoService auto) {
		this.as = auto;
	}


/**
 * trasforma un oggetto in entita	
 * @param autoOggetto
 * @return auto entita
 */
	private Auto dtoToEntity(AutoOggetto autoOggetto) {
		var auto =new Auto();
		auto.setTarga(autoOggetto.getTarga());
		auto.setModello(autoOggetto.getModello());
		auto.setMarca(autoOggetto.getMarca());
		auto.setConcarrivo(autoOggetto.getArrivo());
		auto.setConcprovenienza(autoOggetto.getConcprovenienza());
		auto.setConclavorazione(autoOggetto.getConclavorazione());
		auto.setDataconsegna(autoOggetto.getDataconsegna());
		auto.setDatavendita(autoOggetto.getDatavendita());
		auto.setProprietario(autoOggetto.getProprietario());
		auto.setTelaio(autoOggetto.getTelaio());
		auto.setStato(autoOggetto.getStato());
		auto.setVenduta(autoOggetto.isVenduta());

		return auto;
	}
	
	/**
	 * 
	 * @param targa targa della'auto da cercare
	 * @return auto trovata
	 */
	public Auto findByTarga(String targa) {
		Auto a=as.findByTarga(targa);
		return a;
	}
	
	/**
	 * cambia lo stato di auto 
	 * @param targa dell'auto
	 * @param stato da settare
	 * @return
	 */
	@PostMapping(path="cambiaStatoAuto")
	public Auto cambiaStatoAuto(String targa,Stato s,Posizione p) {
		return as.cambiaStatoAuto(targa,s,p);
	}
	
	@PostMapping(path="findAll")
	public List<Auto> findAll() {
		return as.findAll();
	}

	
	/**
	 * aggiunge un nuova auto nella tabella
	 * @param autoOggetto
	 * @return entita aggiunta
	 */
	@PostMapping(path = "inserisciAuto")
	public Auto inserisciAuto(@Valid @RequestBody AutoOggetto autoOggetto) {
		var auto = dtoToEntity(autoOggetto);
		return as.inserisciAuto(auto);
	}
	
	
	/**
	 * quando il venditore vende un auto richiama questa funzione inserendo i "termini" di vendita
	 * @param targa per risalire all'auto che è stata venduta
	 * @param proprietario nome della persona a cui è stata venduta
	 * @param datavendita data attuale
	 * @param dataconsegna data entro la quale deve essere consegnata la macchina
	 * @param concessionarioconsegna concessionario in cui avverrà la consegna
	 */
	@PostMapping(path="CompraAuto")
	public void CompraAuto(String targa,String proprietario,String datavendita,String dataconsegna,Posizione concessionarioconsegna) {
		as.CompraAuto(targa,proprietario,datavendita,dataconsegna,concessionarioconsegna);
	}
	
	
	/**
	 * una volta che l'algoritmo ha finito il calcolo setta tutti i concessionari di lavorazione delle auto
	 * @param targa per risalire all'auto
	 * @param concessionariolav per inserire dove verrà lavorata l'auto
	 */
	@PostMapping(path="ConcessionarioDiLavorazioneAuto")
	public void ConcessionarioDiLavorazioneAuto(String targa,Posizione concessionariolav) {
	
		as.ConcessionarioDiLavorazioneAuto(targa,concessionariolav);
	}
	
	
	/**
	 * quando un auto ha finito il processo di lavorazione ed è stata consegnata al cliente, o non serve più nella tabella
	 * @param targa per identificare l'auto
	 * @param concessionariaAttuale dove si trova attualmente l'auto
	 */
	@PostMapping(path="RimuoviAuto")
	public void RimuoviAuto(String targa) {	
		as.RimuoviAuto(targa);
		
	}


	public List<Auto> findAllByPosizione(Posizione p) {
		return as.findAllByPosizione(p,findAll());
		
	}


	public List<Auto> findAllByVenduta(boolean b) {
		return as.findAllByVenduta(b);
		
	}


	public List<Auto> findAllByPosizioneAndVenduto(Posizione p, boolean b) {
		return as.findAllByposioneAndVenduta(p,b,findAll());
	}
		
	
}
