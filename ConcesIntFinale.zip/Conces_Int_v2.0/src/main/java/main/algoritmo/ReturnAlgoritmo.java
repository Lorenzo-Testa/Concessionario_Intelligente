package main.algoritmo;

import java.util.HashMap;

public class ReturnAlgoritmo {
private HashMap<String,Risultato> hm;
private ListaConcatenataSuperior[] schedule;



public HashMap<String, Risultato> getHm() {
	return hm;
}



public void setHm(HashMap<String, Risultato> hm) {
	this.hm = hm;
}



public ListaConcatenataSuperior[] getSchedule() {
	return schedule;
}



public void setSchedule(ListaConcatenataSuperior[] schedule) {
	this.schedule = schedule;
}



public ReturnAlgoritmo(HashMap<String, Risultato> hm, ListaConcatenataSuperior[] schedule) {
	super();
	this.hm = hm;
	this.schedule = schedule;
}

}
