package main.algoritmo;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import main.autoManager.Auto;
import main.autoManager.AutoController;
import main.autoManager.Stato;
import main.autoManager.sortAuto;
import main.interventi.Intervento;
import main.officina.Officina;
import main.officina.Posizione;

public class Algoritmov7 {

	private ListaConcatenataSuperior[] schedulazione;

	public ListaConcatenataSuperior[] getSchedulazione() {
		return schedulazione;
	}

	public void setSchedulazione(ListaConcatenataSuperior[] schedulazione) {
		this.schedulazione = schedulazione;
	}

	/**
	 * funzione richiamata dall'esterno che chiama le altre funzioni
	 * 
	 * @param autos       lista di auto
	 * @param officinas   lista di officine
	 * @param interventos lista di interventi
	 * @return hashmap di targa-concessionaria di lavorazione
	 */

	public ReturnAlgoritmo runAlgoritmo(List<Auto> autos, List<Officina> officinas, List<Intervento> interventos) {
		// ordino le auto
		autos = Sort(autos);
		// corpo dell'algoritmo
		ReturnAlgoritmo ra = ricercapercorso(autos, officinas, interventos);
		// ritorno la mappa ordinata con targa-concessionaria di lavorazione
		return ra;

	}

	private ReturnAlgoritmo ricercapercorso(List<Auto> autos, List<Officina> officinas, List<Intervento> interventos) {
		Grafo g = new Grafo();
		HashMap<String, Risultato> hm = new HashMap<String, Risultato>();
		if (schedulazione == null)
			schedulazione = initSchedule(officinas, g);
		ListaConcatenataSuperior[] schedule = initSchedule(officinas, g);
		ListaConcatenataSuperior[] backup = initSchedule(officinas, g);

		// hard copy
		for (int x = 0; x < officinas.size(); x++) {
			backup[x].setStart(schedulazione[x].deepCopy(schedulazione[x].getStart()));
		}
		// hard copy
		for (int x = 0; x < officinas.size(); x++) {
			schedule[x].setStart(schedulazione[x].deepCopy(schedulazione[x].getStart()));
		}

		int[] caricodilavoro = initCapacitaAttuale(officinas, g);
		int[] caricobackup = initCapacitaAttuale(officinas, g);

		// ciclo le auto
		for (int i = 0; i < autos.size(); i++) {

			// Salto le auto già schedulate
			if (!autos.get(i).getStato().equals(Stato.NONSCHEDULATO))
				continue;

			// backup della schedulazione
			for (int x = 0; x < officinas.size(); x++) {
				backup[x].setStart(schedule[x].deepCopy(schedule[x].getStart()));
				caricobackup[x] = caricodilavoro[x];
			}

			Risultato r = new Risultato(10000, null);

			Posizione concessionarioDiPartenza = autos.get(i).getConcprovenienza();
			int indiceConcessionarioDiPartenza = g.getProvenienza(concessionarioDiPartenza);

			Posizione concessionarioDiArrivo = autos.get(i).getConcarrivo();
			int indiceConcessionarioDiArrivo = g.getProvenienza(concessionarioDiArrivo);

			// ciclo le officine
			for (int k = 0; k < officinas.size(); k++) {

				Posizione ConcessionarioAttuale = g.getPosizione(k);
				int indiceConcessionarioAttuale = g.getProvenienza(ConcessionarioAttuale);

				if (caricodilavoro[indiceConcessionarioAttuale] >= officinas.get(indiceConcessionarioAttuale)
						.getCapacitamax())
					continue;
				int tempoLavorazione = tempoLavorazioneAuto(autos.get(i).getTarga(), interventos);
				int tempoarrivoinlavorazione = g
						.getMatrix()[indiceConcessionarioDiPartenza][indiceConcessionarioAttuale];

				int tcalcolato = 0;
				tcalcolato += tempoLavorazione;
				tcalcolato += tempoarrivoinlavorazione;
				tcalcolato += g.getMatrix()[indiceConcessionarioAttuale][indiceConcessionarioDiArrivo];
				if (tcalcolato >= r.tempominimo)
					continue;

				ListaConcatenata ponte = schedule[indiceConcessionarioAttuale].getStart();
				// ciclo i ponti
				for (int p = 0; p < schedule[indiceConcessionarioAttuale].size; p++) {
					int tempoincoda = 0;
					int tempotrascorso = 0;
					Nodo iter = ponte.start;
					// ciclo la lista dei ponti
					for (int j = 0; j < ponte.size; j++) {
						if (tcalcolato + tempoincoda >= r.tempominimo)
							break;
						// se non è ancora arrivato in officina salta al prossimo slot
						if (tempoarrivoinlavorazione > tempotrascorso + iter.peso.getTempo()
								&& iter.peso.getTempo() > 0) {
							tempotrascorso += iter.peso.getTempo();
							iter = iter.next;
							continue;
						}

						// trovo uno slot libero in mezzo ad altri slot
						if (iter.peso.getLibero()
								&& iter.peso.getTempo() >= tempoLavorazione + tempoarrivoinlavorazione - tempotrascorso
								&& iter.peso.getTempo() > tempoLavorazione) {
							int tempolibero = iter.peso.getTempo();
							int tempofineslot = tempolibero + tempotrascorso;
							int temporesiduo2_2 = tempofineslot - tempoarrivoinlavorazione - tempoLavorazione;
							int temporesiduo2_1 = tempolibero - tempoLavorazione;
							int temporesiduo1 = tempoarrivoinlavorazione - tempotrascorso;

							// riporto allo stato di backup
							for (int x = 0; x < officinas.size(); x++) {
								schedule[x].setStart(backup[x].deepCopy(backup[x].getStart()));
								caricodilavoro[x] = caricobackup[x];
							}

							caricodilavoro[indiceConcessionarioAttuale]++;

							// rimuovo lo slot di mezzo per dividerlo
							schedule[indiceConcessionarioAttuale].removeNodo(p, j);

							// se è gia presente nel concessionario all'inizio dello slot
							if (tempoarrivoinlavorazione <= tempotrascorso) {
								schedule[indiceConcessionarioAttuale].addNodo(p, j, tempoLavorazione, false,
										autos.get(i).getTarga());
								r.setTempominimo(tcalcolato + tempoincoda);
								r.setPosizione(g.getPosizione(indiceConcessionarioAttuale));
								if (temporesiduo2_1 > 0) {
									schedule[indiceConcessionarioAttuale].addNodo(p, j + 1, temporesiduo2_1, true);
								}
								break;
							}

							// caso in cui arriva a meta slot
							if (temporesiduo1 > 0) {
								schedule[indiceConcessionarioAttuale].addNodo(p, j, temporesiduo1, true);
								schedule[indiceConcessionarioAttuale].addNodo(p, j + 1, tempoLavorazione, false,
										autos.get(i).getTarga());
								r.setTempominimo(tcalcolato);
								r.setPosizione(g.getPosizione(indiceConcessionarioAttuale));
								if (temporesiduo2_2 > 0) {
									schedule[indiceConcessionarioAttuale].addNodo(p, j + 2, temporesiduo2_2, true);
								}
								break;
							} else {
								schedule[indiceConcessionarioAttuale].addNodo(p, j, tempoLavorazione, false,
										autos.get(i).getTarga());
								r.setTempominimo(tcalcolato + tempoincoda);
								r.setPosizione(g.getPosizione(indiceConcessionarioAttuale));
								if (temporesiduo2_2 > 0) {
									schedule[indiceConcessionarioAttuale].addNodo(p, j + 1, temporesiduo2_2, true);
								}
								break;
							}
						}

						// se la coda è finita
						if (iter.peso.getTempo() < 0 && iter.peso.getLibero()) {

							// riporto allo stato di backup
							for (int x = 0; x < officinas.size(); x++) {
								schedule[x].setStart(backup[x].deepCopy(backup[x].getStart()));
								caricodilavoro[x] = caricobackup[x];
							}

							caricodilavoro[indiceConcessionarioAttuale]++;
							// non è in officina quando finisce la coda
							if (tempoarrivoinlavorazione > tempotrascorso) {
								schedule[indiceConcessionarioAttuale].addNodo(p, j,
										tempoarrivoinlavorazione - tempotrascorso, true);
								schedule[indiceConcessionarioAttuale].addNodo(p, j + 1, tempoLavorazione, false,
										autos.get(i).getTarga());
								r.setPosizione(g.getPosizione(indiceConcessionarioAttuale));
								r.setTempominimo(tcalcolato);
								break;
							}
							// è gia in officina
							else {
								schedule[indiceConcessionarioAttuale].addNodo(p, j, tempoLavorazione, false,
										autos.get(i).getTarga());
								r.setTempominimo(tcalcolato + tempoincoda);
								r.setPosizione(g.getPosizione(indiceConcessionarioAttuale));
								break;
							}
						}

						boolean aggiunto = false;
						// se è arrivato calcolo il tempo rimasto in coda
						if (tempotrascorso >= tempoarrivoinlavorazione) {
							tempoincoda += iter.peso.getTempo();
							aggiunto = true;
						}
						// aggiungo il tempo trascorso in questo slot
						tempotrascorso += iter.peso.getTempo();
						// se è arrivato in questo slot aggiungo il tempo in coda se lo slot non era
						// libero
						if (tempotrascorso > tempoarrivoinlavorazione && !aggiunto) {
							tempoincoda += tempotrascorso - tempoarrivoinlavorazione;
						}
						iter = iter.next;
					}
					ponte = ponte.next;
				}

			}
			hm.put(autos.get(i).getTarga(), r);
		}

		// salva lo schedule finale
		for (int x = 0; x < officinas.size(); x++) {
			schedulazione[x].setStart(schedule[x].deepCopy(schedule[x].getStart()));
		}
		ReturnAlgoritmo ra = new ReturnAlgoritmo(hm, schedule);
		//Per stampare a console la schedulazione delle macchine
//		for(int i = 0; i < schedule.length; i++) {
//			System.out.println(g.getPosizione(i).toString());
//			System.out.println(schedule[i].toString());
//		}
		return ra;
	}

	private int[] initCapacitaAttuale(List<Officina> officinas, Grafo g) {
		int[] capmax = new int[officinas.size()];
		for (int i = 0; i < officinas.size(); i++) {
			capmax[i] = officinas.get(i).getCarico();
		}
		return capmax;
	}

	/**
	 * crea e ritorna le liste delle schedulazioni
	 * 
	 * @param officinas lista delle officine
	 * @return
	 */
	private ListaConcatenataSuperior[] initSchedule(List<Officina> officinas, Grafo g) {
		// if (schedulazione == null) {

		// officinas è la lista di tutte le officine
		// creo una liste di officine superior di grandezza=#officinas
		ListaConcatenataSuperior[] officine = new ListaConcatenataSuperior[officinas.size()];

		// ciclo ogni elemento di officine, cioè ciclo ogni officina e la inizializzo
		for (int i = 0; i < officinas.size(); i++) {
			// officine ha grandezza pari al numero di officine e ogni suo elemento contiene
			// liste null
			officine[i] = new ListaConcatenataSuperior();
		}

		// bisogna aggiungere per ogni indice di officine, una lista grande quanto il
		// carico massimo dell'officina corrispondente

		// ciclo ogni elemento di officine
		for (int j = 0; j < officinas.size(); j++) {

			// setto l'indice corripondente all'indice del grafo, quindi ottengo un indice
			// per ogni officina
			int indice = g.getProvenienza(officinas.get(j).getPosizione());

			// creo un vettore di liste riferito ad ogni officina pari alla grandezza del
			// caricomax
			ListaConcatenata[] officina = new ListaConcatenata[officinas.get(j).getNumPonti()];// tanti elementi
																								// quanti sono i
																								// suoi ponti
			// aggiugno tutti i ponti e li inizializzo
			for (int i = 0; i < officinas.get(j).getNumPonti(); i++) {
				officina[i] = new ListaConcatenata();
				officine[indice].add(i, officina[i]);
				officina[i].add(0, -1, true);
			}
		}
		// schedulazione=officine;

		return officine;
		// }

		// se la schedule non è vuota
		// else {
		// return schedulazione;
		// }

	}

	/**
	 * calcola il tempo totale di lavorazione di un auto
	 * 
	 * @param targa       per identificare l'auto
	 * @param interventos lista degli interventi
	 * @return tempo totale di intervento sull'autovettura
	 */
	private int tempoLavorazioneAuto(String targa, List<Intervento> interventos) {
		int t = 0;
		for (int i = 0; i < interventos.size(); i++) {
			if (interventos.get(i).getId().getTargaAuto().compareTo(targa) == 0)
				t = t + interventos.get(i).getDurata();
		}

		return t;
	}

	/**
	 * permette di ordinare la lista di auto conn il comparate che vogliamo
	 * 
	 * @param a , lista di auto
	 * @return a , lista ordinata
	 */
	private List<Auto> Sort(List<Auto> a) {
		sortAuto s = new sortAuto();
		Collections.sort(a, s);
		return a;
	}

	public void ArrivoInOfficina(int Posizione) {
		for (int i = 0; i < schedulazione[Posizione].size; i++) {
			if (schedulazione[Posizione].getPonte(i).start.peso.getLibero() && schedulazione[Posizione].getPonte(i).start.peso.getTempo()>0) {
				schedulazione[Posizione].getPonte(i).remove(0);
			}
		}
	}

	public void fineIntervento(int ponte, int Posizione) {
		schedulazione[Posizione].getPonte(ponte).remove(0);
		
	}
}
