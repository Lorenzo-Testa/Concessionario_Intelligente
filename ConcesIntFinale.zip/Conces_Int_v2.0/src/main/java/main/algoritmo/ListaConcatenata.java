package main.algoritmo;


public class ListaConcatenata {

        Nodo start;
        ListaConcatenata next;
		int size;
    
		public ListaConcatenata() {
                size = 0;
                start = null;
                next=null;
        }
         
        public ListaConcatenata(ListaConcatenata head) {
			this.size=head.size;
			start=null;
			next=null;
		}

		/**
         * 
         * @param indica in che posizione del for si trova il nodo da rimuove
         */
		public void remove(int indice) {
        	if(indice>size) new Exception("non ci sono cosi tanti nodi");
        	if(indice==0) {
        		start=start.next;
        		size--;
        		return;
        	}
        	if(indice==1) {
        		start.next=start.next.next;
        		size--;
        		return;
        	}
        	Nodo iter=start.next;
        	for(int i=1;i<indice-1;i++) {
                iter=iter.next;
        	}	
        	iter.next=iter.next.next;
        	size--;
        }
        
       /**
        * inserisci un nodo all'indice i
        * @param indice
        * @param tempo
        * @param b
        */
       public void add(int indice,int tempo,boolean b,String targa) {
    	   Peso p=new Peso(tempo,b,targa);
    	   Nodo newNodo = new Nodo(p);
       	if(indice==0) {
       		newNodo.next=start;
       		start=newNodo;
       		size++;
       		return;
       	}
       	if(indice==1) {
       		newNodo.next=start.next;
       		start.next=newNodo;
       		size++;
       		return;
       	}
       	Nodo iter=start.next;
       	for(int i=1;i<indice-1;i++) {
               iter=iter.next;
       	}	
       	newNodo.next=iter.next;
       	iter.next=newNodo;
       	size++;
    	  
       }
       
       public void add(int indice,int tempo,boolean b) {
    	   Peso p=new Peso(tempo,b);
    	   Nodo newNodo = new Nodo(p);
       	if(indice==0) {
       		newNodo.next=start;
       		start=newNodo;
       		size++;
       		return;
       	}
       	if(indice==1) {
       		newNodo.next=start.next;
       		start.next=newNodo;
       		size++;
       		return;
       	}
       	Nodo iter=start.next;
       	for(int i=1;i<indice-1;i++) {
               iter=iter.next;
       	}	
       	newNodo.next=iter.next;
       	iter.next=newNodo;
       	size++;
    	  
       }
       
       public int getSize() {
			return size;
		}

		public void setSize(int size) {
			this.size = size;
		}
		
        public Nodo getStart() {
			return start;
		}

		public void setStart(Nodo start) {
			this.start = start;
		}

		@Override
		public String toString() {
			String s="";
			Nodo iter=this.start;
			if(iter==null) return s;
			for(int i=1;i>0;i++) {
				s+=iter.peso.getTempo()+"-";
			if(!iter.peso.getLibero()) s+=iter.peso.getTarga()+" | ";
			else s+="Libero\n";
			
				if(iter.next==null) break;
				else iter=iter.next;
				
			}
			return s;
			
		}
		
		public String[] ListaTarghe() {
			String[] lt=new String[size];
			Nodo iter=this.start;
			int x=0;
			if(iter==null) return lt;
			for(int i=1;i>0;i++) {
			if(!iter.peso.getLibero()) {
				lt[x]=iter.peso.getTarga();
				x++;
			}
				if(iter.next==null) break;
				else iter=iter.next;				
			}
			return lt;
			
		}
		
		public Nodo deepCopy(Nodo head) {
		    if (head==null) return head;
		
		    Nodo n=new Nodo(head.peso);
		    
		    n.next = deepCopy(head.next);
		    
		    return n;
		    		
		}

}



