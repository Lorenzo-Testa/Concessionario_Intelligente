package main.algoritmo;


public class Peso {
	
	 private int tempo;

	private boolean libero;
	
	private String targa;
	

	public String getTarga() {
		return targa;
	}

	public void setTarga(String targa) {
		targa = targa;
	}

	public Peso(int i,boolean b,String t){
		tempo=i;
		libero=b;
		targa=t;
	}
	
	public Peso(int i,boolean b){
		tempo=i;
		libero=b;
		targa="";
	}
	
	public void setPeso(int tempo,boolean libero,String targa) {
		this.tempo=tempo;
		this.libero=libero;
		this.targa=targa;
	}
	

	public int getTempo() {
		return tempo;
	}

	public void setTempo(int tempo) {
		this.tempo = tempo;
	}

	public boolean getLibero() {
		return libero;
	}

	public void setLibero(boolean libero) {
		this.libero = libero;
	}
	

}
