package main.algoritmo;

public class Nodo {
	
	Peso peso;
	Nodo next;
	
	
	public Nodo(Peso p) {
		peso=p;
		next=null;
	}
	/*
	 * public Nodo(int tempo,boolean libero) { this.tempo=tempo; this.libero=libero;
	 * } public Nodo() { tempo=100; libero=true; next=null; }
	 */
	
}
