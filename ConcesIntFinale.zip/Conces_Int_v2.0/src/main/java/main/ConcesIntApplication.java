package main;

import java.util.ArrayList;
import java.util.List;

import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.DateTime;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Text;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.batch.BatchAutoConfiguration;

import com.fasterxml.jackson.annotation.JsonTypeInfo.As;

import main.algoritmo.Algoritmov7;
import main.algoritmo.ListaConcatenata;
import main.algoritmo.ListaConcatenataSuperior;
import main.algoritmo.ReturnAlgoritmo;
import main.autoManager.Auto;
import main.autoManager.AutoController;
import main.autoManager.Stato;
import main.interventi.Intervento;
import main.interventi.InterventoController;
import main.officina.*;

@SpringBootApplication(exclude = BatchAutoConfiguration.class)
public class ConcesIntApplication implements CommandLineRunner {

	@Autowired
	InterventoController ic;
	@Autowired
	AutoController ac;
	@Autowired
	OfficinaController oc;

	Algoritmov7 algoritmo = new Algoritmov7();

	public static void main(String[] args) {
		SpringApplication.run(ConcesIntApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		openMenu();

	}

	/**
	 * lancia l'algoritmo
	 */
	public ListaConcatenataSuperior[] LanciaAlgoritmo() {
		List<Auto> ListaAuto = ac.findAllByVenduta(true);
		List<Intervento> ListaIntervento = ic.findAll();
		List<Officina> ListaOfficina = oc.findAll();
		ReturnAlgoritmo ra = algoritmo.runAlgoritmo(ListaAuto, ListaOfficina, ListaIntervento);
		
		// update del concessionario di lavorazione scelto dall'algoritmo e dello stato
		// dell'auto
		for (String key : ra.getHm().keySet()) {
			ac.ConcessionarioDiLavorazioneAuto(key, ra.getHm().get(key).getPosizione());
			Auto a = ac.findByTarga(key);
			Stato s = TrovaStato(a.getConcprovenienza(), a.getConclavorazione());
			ac.cambiaStatoAuto(key, s, ac.findByTarga(key).trovaPosizione());
			

		}
		return ra.getSchedule();
		// return algoritmo.runAlgoritmo(ListaAuto, ListaOfficina, ListaIntervento);
	}

	private Stato TrovaStato(Posizione a, Posizione b) {
		if (a.equals(b))
			return Stato.INCODA;
		else
			return Stato.SCHEDULATO;
	}

////////////////////////////////////	MENU	/////////////////////////////////////////////////////////////////////
	public void openMenu() {
		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setSize(678, 355);
		shell.setText("SWT Application");
		Label lblPosizione = new Label(shell, SWT.NONE);
		lblPosizione.setBounds(87, 68, 70, 18);
		lblPosizione.setText("Posizione");

		Combo comboPosizione = new Combo(shell, SWT.NONE);
		comboPosizione.setItems(new String[] { "MILANO", "TORINO", "BOLOGNA", "VENEZIA", "GENOVA" });
		comboPosizione.setBounds(229, 68, 249, 23);

		Label lblCapoFiliale = new Label(shell, SWT.NONE);
		lblCapoFiliale.setBounds(291, 203, 95, 18);
		lblCapoFiliale.setText("CAPO OFFICINA");

		Button btnLogin = new Button(shell, SWT.NONE);
		btnLogin.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Posizione p = Posizione.valueOf(comboPosizione.getText());
				shell.close();
				openCapoOfficina(p);

			}
		});
		btnLogin.setBounds(291, 237, 90, 25);
		btnLogin.setText("LOGIN");

		Button btnLoginMeccanico = new Button(shell, SWT.NONE);
		btnLoginMeccanico.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Posizione p = Posizione.valueOf(comboPosizione.getText());
				shell.close();
				openMeccanico(oc.NumeroPonti(p), p);

			}
		});
		btnLoginMeccanico.setBounds(56, 237, 75, 25);
		btnLoginMeccanico.setText("LOGIN");

		Label lblMeccanico = new Label(shell, SWT.NONE);
		lblMeccanico.setBounds(56, 203, 80, 23);
		lblMeccanico.setText("MECCANICO");

		Button btnLoginVenditore = new Button(shell, SWT.NONE);
		btnLoginVenditore.setBounds(536, 237, 75, 25);
		btnLoginVenditore.setText("LOGIN");
		
		btnLoginVenditore.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				Posizione p = Posizione.valueOf(comboPosizione.getText());
				shell.close();
				openVenditore(p);

			}
		});

		Label lblVenditore = new Label(shell, SWT.NONE);
		lblVenditore.setBounds(543, 203, 95, 23);
		lblVenditore.setText("VENDITORE");

		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

/////////////////////////////	CAPO-OFFICINA	///////////////////////////////////////////////////////////////

	public void openCapoOfficina(Posizione p) {

		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setSize(926, 389);
		shell.setText("SWT Application");
		Label labelSchedule = new Label(shell, SWT.NONE);
		labelSchedule.setBounds(10, 10, 300, 300);
		labelSchedule.setText("schedule");


		Text targa = new Text(shell, SWT.BORDER);
		targa.setBounds(642, 167, 76, 21);
		Combo combo = new Combo(shell, SWT.NONE);
		combo.setItems(new String[] { "coda", "lavorazione", "trasporto all'officina di lavorazione",
				"trasporto all'officina di vendita","arrivo al punto di consegna" });
		combo.setBounds(769, 167, 91, 23);
		Label lblListaAuto = new Label(shell, SWT.NONE);
		lblListaAuto.setBounds(327, 10, 300, 300);
		lblListaAuto.setText("Lista auto:");

		Button btnAggiorna = new Button(shell, SWT.NONE);
		btnAggiorna.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {

				labelSchedule.setText(LanciaAlgoritmo()[p.ordinal()].toString());
				lblListaAuto.setText(ac.findAllByPosizioneAndVenduto(p,true).toString());

			}
		});
		btnAggiorna.setBounds(254, 318, 75, 25);
		btnAggiorna.setText("AGGIORNA");

		Button btnLogout = new Button(shell, SWT.NONE);
		btnLogout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.close();
				openMenu();
			}
		});
		btnLogout.setBounds(825, 318, 75, 25);
		btnLogout.setText("LOGOUT");

		Button btnCambiaStato = new Button(shell, SWT.NONE);
		btnCambiaStato.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String targaAuto = targa.getText();
				String stato = combo.getText();
				Stato s = null;
				switch (stato) {
				case "coda":
					s = Stato.INCODA;
					break;
				case "lavorazione":
					s = Stato.INLAVORAZIONE;
					algoritmo.ArrivoInOfficina(p.ordinal());
					break;
				case "trasporto all'officina di lavorazione":
					s = Stato.TRASPORTO1;
					break;
				case "trasporto all'officina di vendita":
					s = Stato.TRASPORTO2;
					break;
				case "arrivo al punto di consegna":
					s=Stato.FINITO;
					break;
				}
				ac.cambiaStatoAuto(targaAuto, s, p);

			}
		});
		btnCambiaStato.setBounds(704, 194, 75, 25);
		btnCambiaStato.setText("Cambia Stato");
		
		
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
	
//////////////////////////	MECCANICO	///////////////////////////////////////////////////////////

	public void openMeccanico(int x, Posizione p) {
		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setSize(926, 389);
		shell.setText("SWT Application");

		Combo combo = new Combo(shell, SWT.NONE);
		combo.setBounds(94, 10, 116, 23);
		switch (x) {
		case 1:
			combo.setItems("Ponte 1");
			break;
		case 2:
			combo.setItems("Ponte 1", "Ponte 2");
			break;
		case 3:
			combo.setItems("Ponte 1", "Ponte 2", "Ponte 3");
			break;
		case 4:
			combo.setItems("Ponte 1", "Ponte 2", "Ponte 3", "Ponte 4");
			break;
		default:
			combo.setItems("errore");
			break;
		}

		Label ListaAutoPonte = new Label(shell, SWT.NONE);
		ListaAutoPonte.setBounds(10, 51,250, 183);

		Text TextTarga = new Text(shell, SWT.BORDER);
		TextTarga.setBounds(10, 295, 76, 21);

		Text TextLavoro = new Text(shell, SWT.BORDER);
		TextLavoro.setBounds(134, 295, 76, 21);

		Button btnEseguito = new Button(shell, SWT.NONE);
		btnEseguito.setBounds(250, 293, 75, 25);
		btnEseguito.setText("ESEGUITO");
		btnEseguito.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				if(ic.findAllByTargaAndEseguito(TextTarga.getText(),false).isEmpty()) {
				String pontestr = combo.getText();
				int ponte = Integer.parseInt(pontestr.substring(6));
				algoritmo.fineIntervento(ponte,p.ordinal());
				}
				ic.interventoTerminato(TextTarga.getText(), TextLavoro.getText());
			}
		});
		Label lblListaLavori = new Label(shell, SWT.NONE);
		lblListaLavori.setBounds(456, 13, 422, 243);

		Button btnSeleziona = new Button(shell, SWT.NONE);
		btnSeleziona.setBounds(250, 8, 75, 25);
		btnSeleziona.setText("SELEZIONA");
		btnSeleziona.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				String pontestr = combo.getText();
				int ponte = Integer.parseInt(pontestr.substring(6));
			
			 	if (algoritmo.getSchedulazione() == null)
			 
					ListaAutoPonte.setText("non è stato schedulato nessun lavoro");
				else {
					String[] temp = algoritmo.getSchedulazione()[p.ordinal()].getPonte(ponte).ListaTarghe();
					
					String s="";
					for(int i=0;i<temp.length;i++) {
						if(temp[i]!=null) s+=ac.findByTarga(temp[i]).TargaMarcaModello();
						if(i==0) lblListaLavori.setText(ic.IntereventiAuto(temp[0]));
					}

					ListaAutoPonte.setText(s);
				}
				
			 	
			}
			
		});

		Button btnLogout = new Button(shell, SWT.NONE);
		btnLogout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.close();
				openMenu();
			}
		});
		btnLogout.setBounds(825, 318, 75, 25);
		btnLogout.setText("LOGOUT");
		
		
		
		Label lblTarga = new Label(shell, SWT.NONE);
		lblTarga.setBounds(27, 278, 38, 15);
		lblTarga.setText("Targa");
		
		Label lblLavoro = new Label(shell, SWT.NONE);
		lblLavoro.setBounds(155, 274, 55, 15);
		lblLavoro.setText("Lavoro");

		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}
	
/////////////////////////////////// VENDITORE ///////////////////////////////////////////
	public void openVenditore(Posizione p) {
		
		Display display = Display.getDefault();
		Shell shell = new Shell();
		shell.setSize(926, 389);
		shell.setText("SWT Application");
		
		Label lblListaAutoNonVendute = new Label(shell, SWT.NONE);
		lblListaAutoNonVendute.setBounds(410, 39, 411, 259);
		List<Auto> autovenduta = new ArrayList<Auto>();
		autovenduta=ac.findAllByVenduta(false);
		String s="";
		for(int i=0;i<autovenduta.size();i++) {
			s+=autovenduta.get(i).getConcprovenienza().toString()+" | "+autovenduta.get(i).TargaMarcaModello();
		}
		
		lblListaAutoNonVendute.setText(s);
		
		Text txttarga = new Text(shell, SWT.BORDER);
		txttarga.setBounds(102, 36, 76, 21);
		
		Label lblTarga = new Label(shell, SWT.NONE);
		lblTarga.setBounds(21, 39, 55, 15);
		lblTarga.setText("targa");
		
		Text txtproprietario = new Text(shell, SWT.BORDER);
		txtproprietario.setBounds(102, 63, 76, 21);
		
		Label lblProprietario = new Label(shell, SWT.NONE);
		lblProprietario.setBounds(21, 71, 71, 15);
		lblProprietario.setText("proprietario");
		
		Text datavendita = new Text(shell, SWT.BORDER);
		datavendita.setBounds(102, 94, 80, 24);
		
		Label lblDataVendita = new Label(shell, SWT.NONE);
		lblDataVendita.setBounds(21, 97, 65, 15);
		lblDataVendita.setText("data vendita");
		
		Text dataconsegna = new Text(shell, SWT.BORDER);
		dataconsegna.setBounds(102, 124, 80, 24);
		
		Label lblDataConsegna = new Label(shell, SWT.NONE);
		lblDataConsegna.setBounds(21, 124, 80, 15);
		lblDataConsegna.setText("data consegna");
		
		
		
		Button btnVendita = new Button(shell, SWT.NONE);
		btnVendita.setBounds(67, 250, 128, 25);
		btnVendita.setText("VendiAuto");		
		btnVendita.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				
				ac.CompraAuto(txttarga.getText(), txtproprietario.getText(), datavendita.getText(), dataconsegna.getText(), p);
				
				List<Auto> autovenduta = new ArrayList<Auto>();
				autovenduta=ac.findAllByVenduta(false);
				String s="";
				for(int i=0;i<autovenduta.size();i++) {
					s+=autovenduta.get(i).getConcprovenienza().toString()+" | "+autovenduta.get(i).TargaMarcaModello();
				}
				
				lblListaAutoNonVendute.setText(s);
				
				
			}
		});
		
		Button btnLogout = new Button(shell, SWT.NONE);
		btnLogout.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				shell.close();
				openMenu();
			}
		});
		btnLogout.setBounds(825, 318, 75, 25);
		btnLogout.setText("LOGOUT");
		
		shell.open();
		shell.layout();
		while (!shell.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
		
	}
	
/////////////////////////////////POST-VENDITA/////////////////////////////////////////
	//TODO
/////////////////////////////////
}



