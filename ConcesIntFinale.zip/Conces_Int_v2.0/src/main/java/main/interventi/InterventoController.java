package main.interventi;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import main.officina.Posizione;




@RestController
public class InterventoController {
	
	@Autowired
	private InterventoService is;
	
	public InterventoController(InterventoService intervento) {
		this.is = intervento;
	}
	
	
	private Intervento dtoToEntity(InterventoOggetto interventoOggetto) {
		var intervento =new Intervento();
		intervento.setId(interventoOggetto.getId());
		intervento.setEseguito(interventoOggetto.isEseguito());
		intervento.setOfficina(interventoOggetto.getOfficina());
		intervento.setDurata(interventoOggetto.getDurata());
		return intervento;
	}
	
	@PostMapping(path = "inserisciIntervento")
	public Intervento inserisciIntervento(@Valid @RequestBody InterventoOggetto interventoOggetto) {
		var intervento = dtoToEntity(interventoOggetto);
		return is.inserisciIntervento(intervento);
	}
	
	@PostMapping(path="interventoTerminato")
	public void interventoTerminato(String targa,String lavoro) {
		idIntervento id=new idIntervento(targa,lavoro);
		is.interventoTerminato(id);
	}
	
	@PostMapping(path="officinaLavorazione")
	public void officinaLavorazione(String targa,Posizione officinadilavorazione) {
		is.officinaLavorazione(targa,officinadilavorazione);
	}
	
	@GetMapping(path="tempoLavorazioneAuto")
	public int tempoLavorazioneAuto(String targa){
		int t=is.tempoLavorazioneAuto(targa);
		return t;
	}

	/**
	 * 
	 * @param targa
	 * @return
	 */
	@GetMapping(path="interventiAuto")
	public String IntereventiAuto(String targa){
		String s="";
		s+=targa+" : \n";
		s+=is.findAllByTarga(targa);
		return s;
	}

	public List<Intervento> findAll() {
		return is.findAll();
	}

	public List<Intervento> findAllByTargaAndEseguito(String targa, boolean b) {
		return is.findAllByTargaAndEseguito(targa,b);
		
	}

}
