package main.interventi;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import main.autoManager.Auto;
import main.officina.Posizione;

@Entity
public class Intervento {
	

	@EmbeddedId
	private idIntervento id;
	
	@Column
	private int durata;
	
	@Column
	private boolean eseguito ;
	
	@Enumerated(EnumType.STRING)
	@Column
	private Posizione officina;
	
	public Intervento() {}
	
	public Intervento(idIntervento id, int durata, boolean eseguito) {
		super();
		this.id = id;
		this.durata = durata;
		this.eseguito = eseguito;
		this.officina=null;	
	}
	
	public Posizione getOfficina() {
		return officina;
	}

	public void setOfficina(Posizione officina) {
		this.officina = officina;
	}
	
	public int getDurata() {
		return durata;
	}

	public void setDurata(int durata) {
		this.durata = durata;
	}


	public idIntervento getId() {
		return id;
	}

	public void setId(idIntervento id) {
		this.id = id;
	}

	public boolean isEseguito() {
		return eseguito;
	}

	public void setEseguito(boolean eseguito) {
		this.eseguito = eseguito;
	}
	
	@Override
	public String toString() {
		String s="";
		s+=this.id.getLavoro()+" ,durata :  "+this.durata+" | ";
		if(eseguito) s+="lavoro terminato";
		else s+="non eseguito";
		return s+="\n";
	}
	
}
