package main.interventi;

import java.util.List;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InterventoRepository extends CrudRepository<Intervento, idIntervento>{

	List<Intervento> findAllByIdTargaAuto(String targa);

	List<Intervento> findAllByidTargaAutoAndEseguito(String targa,Boolean b);
}
