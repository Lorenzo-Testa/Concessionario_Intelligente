package main.interventi;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import main.officina.Posizione;



@Service
public class InterventoService {
	
	@Autowired
	private InterventoRepository ir;
	
	

	
	public InterventoService(InterventoRepository intervento) {
		this.ir = intervento;
	}

	public Intervento inserisciIntervento(Intervento  nuovoIntervento) {
		return ir.save(nuovoIntervento);
	}

	public void interventoTerminato(idIntervento id) {
		Optional<Intervento> i =ir.findById(id);
		if(i.isEmpty())throw new ResponseStatusException(HttpStatus.NOT_FOUND, "l'intervento non esiste");
		if(i.get().isEseguito()) new Exception("l'intervento è già terminato");
		i.get().setEseguito(true);
		ir.save(i.get());
	}

	public void officinaLavorazione(String targa, Posizione officinadilavorazione) {
		List<Intervento> i =ir.findAllByIdTargaAuto(targa);
		if(i.isEmpty())throw new ResponseStatusException(HttpStatus.NOT_FOUND, "l'intervento non esiste");
		for(int a=0;a<i.size();a++) {
			i.get(a).setOfficina(officinadilavorazione);
		}
		ir.saveAll(i);
	}

	public int tempoLavorazioneAuto(String targa) {
		List<Intervento> i =ir.findAllByIdTargaAuto(targa);
		int t=0;
		for(int a=0;a<i.size();a++) {
			t=t+i.get(a).getDurata();
		}
		return t;
	}

	public List<Intervento> saveAll(List<Intervento> il) {
		Iterable<Intervento> i=new ArrayList<>();
		i=ir.saveAll(il);
		return (List<Intervento>) i;
	}

	public List<Intervento> findAll() {
		return (List<Intervento>) ir.findAll();
	}

	public String findAllByTarga(String targa) {
		return ir.findAllByIdTargaAuto(targa).toString();
		
	}

	public List<Intervento> findAllByTargaAndEseguito(String targa, boolean b) {
	return 	ir.findAllByidTargaAutoAndEseguito(targa,b);
		
	}

//	public void RimuoviInterventi(String targa) {
	//	ir.deleteAllByTarga(targa);
		//ir.de
		
	//}


}
