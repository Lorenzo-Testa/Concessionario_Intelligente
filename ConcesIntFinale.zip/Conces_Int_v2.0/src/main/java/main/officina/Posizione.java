package main.officina;

import main.algoritmo.Grafo;

public enum Posizione {

	MILANO,TORINO,BOLOGNA,VENEZIA,GENOVA;
	
	


}