package main.officina;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
public class Officina {
	
	@Enumerated(EnumType.STRING)
	@Id
	private Posizione posizione;
	
	@Column(nullable = false)
	private int carico;
	
	@Column(nullable = false)
	private int capacitamax;
	
	@Column(nullable=false)
	private int numponti;

	@Column(nullable=false)
	private int tempoincoda;
	

	public Officina() {
	}
	
	public Officina(Posizione posizione, int capacitamax, int numPonti) {
		super();
		this.posizione = posizione;
		this.carico = 0;
		this.capacitamax = capacitamax;
		this.numponti=numPonti;
		this.tempoincoda=0;
	}
	

	public Posizione getPosizione() {
		return posizione;
	}

	public void setPosizione(Posizione posizione) {
		this.posizione = posizione;
	}

	public int getCarico() {
		return carico;
	}

	public void setCarico(int carico) {
		this.carico = carico;
	}

	public int getCapacitamax() {
		return capacitamax;
	}

	public void setCapacitamax(int capacitamax) {
		this.capacitamax = capacitamax;
	}

	public int getTempoincoda() {
		return tempoincoda;
	}

	public void setTempoincoda(int tempoincoda) {
		this.tempoincoda = tempoincoda;
	}
	public int getNumPonti() {
		return numponti;
	}

	public void setNumPonti(int caricomax) {
		this.numponti = caricomax;
	}

}
