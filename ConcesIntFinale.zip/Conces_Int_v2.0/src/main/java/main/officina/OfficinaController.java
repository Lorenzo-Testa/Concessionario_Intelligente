package main.officina;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@Controller
public class OfficinaController {
	
	@Autowired
	OfficinaService officinaservice;
	
	public OfficinaController(OfficinaService os) {
		officinaservice=os;
	}
	
	@SuppressWarnings("unused")
	private Officina dtoToEntity(OfficinaOggetto officinaoggetto) {
		Officina o=new Officina();
		o.setPosizione(officinaoggetto.getPosizione());
		o.setCarico(officinaoggetto.getCarico());
		o.setCapacitamax(officinaoggetto.getCapacitamax());
		o.setNumPonti(officinaoggetto.getNumPonti());
		return o;
	}
	
	@PostMapping(path="aggiungiOfficina")
	public void aggiungiOfficina(@Valid @RequestBody OfficinaOggetto og) {
		var officina = dtoToEntity(og);
		officinaservice.aggiungiOfficina(officina);
	}
	
	@PostMapping(path="aggiungi")
	public void aggiungi(Posizione concessionario,int t) {
		officinaservice.aggiungi(concessionario,t);
	}
	
	@PostMapping(path="rimuovi")
	public void rimuovi(Posizione concessionario,int t) {
		officinaservice.rimuovi(concessionario,t);
	}
	
	@PostMapping(path="NumeroPonti")
	public int NumeroPonti(Posizione concessionario) {
		return officinaservice.NumeroPonti(concessionario);
	}

	public List<Officina> findAll() {
		return officinaservice.findAll();
	}

}
