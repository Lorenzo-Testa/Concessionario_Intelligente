package main.officina;

public class OfficinaOggetto {
private Posizione posizione;
private int carico;
private int numPonti;
private int capacitamax;
private int tempoincoda;

public OfficinaOggetto(Posizione posizione, int carico, int capacitamax, int numPonti) {
	super();
	this.posizione = posizione;
	this.carico = carico;
	this.capacitamax = capacitamax;
	this.setNumPonti(numPonti);
	this.tempoincoda = 0;
}

public Posizione getPosizione() {
	return posizione;
}
public void setPosizione(Posizione posizione) {
	this.posizione = posizione;
}

public int getCarico() {
	return carico;
}

public void setCarico(int carico) {
	this.carico = carico;
}

public int getCapacitamax() {
	return capacitamax;
}

public void setCapacitamax(int capacitamax) {
	this.capacitamax = capacitamax;
}

public int getNumPonti() {
	return numPonti;
}

public void setNumPonti(int numPonti) {
	this.numPonti = numPonti;
}

public int getTempoInCoda() {
	return tempoincoda;
}

}
