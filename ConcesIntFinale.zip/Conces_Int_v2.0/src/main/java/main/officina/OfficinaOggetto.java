package main.officina;

public class OfficinaOggetto {
private Posizione posizione;
private int carico;
private int caricomax;


public OfficinaOggetto(Posizione posizione, int carico, int capacitamax,int caricomax) {
	super();
	this.posizione = posizione;
	this.carico = carico;
	this.capacitamax = capacitamax;
	this.setCaricomax(caricomax);
}

public Posizione getPosizione() {
	return posizione;
}
public void setPosizione(Posizione posizione) {
	this.posizione = posizione;
}

public int getCarico() {
	return carico;
}
public void setCarico(int carico) {
	this.carico = carico;
}
public int getCapacitamax() {
	return capacitamax;
}
public void setCapacitamax(int capacitamax) {
	this.capacitamax = capacitamax;
}
public int getCaricomax() {
	return caricomax;
}

public void setCaricomax(int caricomax) {
	this.caricomax = caricomax;
}
private int capacitamax;




}
