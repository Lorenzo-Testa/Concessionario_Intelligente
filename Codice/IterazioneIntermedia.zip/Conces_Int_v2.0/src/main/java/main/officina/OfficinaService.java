package main.officina;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

@Service
public class OfficinaService {
	
	@Autowired
	OfficinaRepository officinarepository;
	
	public OfficinaService (OfficinaRepository or) {
		officinarepository=or;
	}

	public void aggiungi(Posizione concessionario,int t) {
		Optional<Officina> o=officinarepository.findById(concessionario);
		if (!o.isPresent()) new ResponseStatusException(HttpStatus.NOT_FOUND, "l'officina non esiste");
		if(o.get().getCarico()+1>o.get().getCapacitamax()) new Exception("carico massimo raggiunto");
		o.get().setCarico(o.get().getCarico()+1);
		o.get().setTempoincoda(o.get().getTempoincoda()+t);
		officinarepository.save(o.get());
	}
	
	public void rimuovi(Posizione concessionario,int t) {
		Optional<Officina> o=officinarepository.findById(concessionario);
		if (!o.isPresent()) new ResponseStatusException(HttpStatus.NOT_FOUND, "l'officina non esiste");
		o.get().setCarico(o.get().getCarico()-1);
		o.get().setTempoincoda(o.get().getTempoincoda()-t);
		officinarepository.save(o.get());
	}

	public List<Officina> saveAll(List<Officina> o) {
		List<Officina>list=(List<Officina>) officinarepository.saveAll(o);
		return list;
	}


	
}
