package main.officina;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;

@Entity
public class Officina {
	
	@Enumerated(EnumType.STRING)
	@Id
	private Posizione posizione;
	
	@Column(nullable = false)
	private int carico;
	
	@Column(nullable = false)
	private int capacitamax;
	
	@Column(nullable=false)
	private int caricomax;

	@Column(nullable=false)
	private int tempoincoda;
	

	public Officina() {
	}
	
	public Officina(Posizione posizione, int capacitamax,int caricomax) {
		super();
		this.posizione = posizione;
		this.carico = 0;
		this.capacitamax = capacitamax;
		this.caricomax=caricomax;
		this.tempoincoda=0;
	}
	

	public Posizione getPosizione() {
		return posizione;
	}

	public void setPosizione(Posizione posizione) {
		this.posizione = posizione;
	}

	public int getCarico() {
		return carico;
	}

	public void setCarico(int carico) {
		this.carico = carico;
	}

	public int getCapacitamax() {
		return capacitamax;
	}

	public void setCapacitamax(int capacitamax) {
		this.capacitamax = capacitamax;
	}

	public int getTempoincoda() {
		return tempoincoda;
	}

	public void setTempoincoda(int tempoincoda) {
		this.tempoincoda = tempoincoda;
	}
	public int getCaricomax() {
		return caricomax;
	}

	public void setCaricomax(int caricomax) {
		this.caricomax = caricomax;
	}

}
