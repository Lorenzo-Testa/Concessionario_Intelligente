package main.officina;

public enum Posizione {

	MILANO,TORINO,BOLOGNA,VENEZIA,GENOVA;
}
