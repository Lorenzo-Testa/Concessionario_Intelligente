package main.algoritmo;


public class Peso {
	
	 private int tempo;

	private boolean libero;
	
	public Peso(int i,boolean b){
		tempo=i;
		libero=b;
	}
	
	public void setPeso(int tempo,boolean libero) {
		this.tempo=tempo;
		this.libero=libero;
	}
	

	public int getTempo() {
		return tempo;
	}

	public void setTempo(int tempo) {
		this.tempo = tempo;
	}

	public boolean getLibero() {
		return libero;
	}

	public void setLibero(boolean libero) {
		this.libero = libero;
	}
	

}
