package main.algoritmo;

public class ListaConcatenataSuperior {

	ListaConcatenata start;
	int size=0;
	
	public ListaConcatenataSuperior() {
        size = 0;
        start = null;
}
	
	
	/**
     * 
     * @param indica in che posizione del for si trova il nodo da rimuove
     */
	public void remove(int indice) {
    	if(indice>size) new Exception("non ci sono cosi tanti nodi");
    	if(indice==0) {
    		start=start.next;
    		size--;
    		return;
    	}
    	if(indice==1) {
    		start.next=start.next.next;
    		size--;
    		return;
    	}
    	ListaConcatenata iter=start.next;
    	for(int i=1;i<indice-1;i++) {
            iter=iter.next;
    	}	
    	iter.next=iter.next.next;
    	size--;
    }
	
	public void removeNodo(int indicelista,int indiceNodo) {
		if(indicelista==0) {start.remove(indiceNodo); return;}
		if(indicelista==1) { start.next.remove(indiceNodo); return;}
		ListaConcatenata iter=start.next;
		for(int i=1;i<indicelista;i++) {
			iter=iter.next;
		}
		iter.remove(indiceNodo);
	}
	
	
	public void addNodo(int indicelista,int indiceNodo,int tempo,boolean b) {
		if(indicelista==0) {start.add(indiceNodo, tempo, b); return;}
		if(indicelista==1) {start.next.add(indiceNodo, tempo, b); return;}
		ListaConcatenata iter=start.next;
		for(int i=1;i<indicelista;i++) {
			iter=iter.next;
		}
		iter.add(indiceNodo, tempo, b);
	}
    
   /**
    * inserisci un nodo all'indice i
    * @param indice
    * @param tempo
    * @param b
    */
   public void add(int indice,ListaConcatenata lista) {
	   ListaConcatenata newNodo = lista;
   	if(indice==0) {
   		newNodo.next=start;
   		start=newNodo;
   		size++;
   		return;
   	}
   	if(indice==1) {
   		newNodo.next=start.next;
   		start.next=newNodo;
   		size++;
   		return;
   	}
   	ListaConcatenata iter=start.next;
   	for(int i=1;i<indice-1;i++) {
           iter=iter.next;
   	}	
   	newNodo.next=iter.next;
   	iter.next=newNodo;
   	size++;
	  
   }
   
   public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}
	
    public ListaConcatenata getStart() {
		return start;
	}

	public void setStart(ListaConcatenata start) {
		this.start = start;
	}

	@Override
	public String toString() {
		String s="\n";
		ListaConcatenata iter=this.start;
		for(int i=1;i>0;i++) {
			s+="PONTE "+i+" --->";
			s+=iter.toString();
			if(iter.next==null) break;
			else iter=iter.next;
			
		}
		return s;
		
	}
	
	public ListaConcatenata deepCopy(ListaConcatenata head) {
	    if (head==null) return head;
	
	    ListaConcatenata n=new ListaConcatenata(head);
	    n.setStart(head.deepCopy(head.getStart()));
	    
	    n.next = deepCopy(head.next);
	    
	    return n;
	    		
	}



}

	

