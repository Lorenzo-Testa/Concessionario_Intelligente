package main.algoritmo;

import main.officina.Posizione;

public class Risultato {
	int tempominimo;
	Posizione posizione;
	public Risultato(int i, Posizione p) {
		tempominimo=i;
		posizione=p;
	}
	public int getTempominimo() {
		return tempominimo;
	}
	public void setTempominimo(int tempominimo) {
		this.tempominimo = tempominimo;
	}
	public Posizione getPosizione() {
		return posizione;
	}
	public void setPosizione(Posizione posizione) {
		this.posizione = posizione;
	}
	
	@Override
	public String toString(){
		String s="tempo :"+tempominimo;
		s+="	";
		s+="posizione :"+posizione;
		s+="\n";
		return s;
		
	}
}
