package main.algoritmo;

import java.util.Arrays;

import main.autoManager.Auto;
import main.officina.Posizione;

public class Grafo {
	private int[][] matrix ;
	
	private int milano;
	private int torino;
	private int genova;
	private int venezia;
	private int bologna;
	
	
	public Grafo()
	{
		
	Posizione[] nameLookup =new Posizione[5];
	nameLookup[0] = Posizione.MILANO;
	nameLookup[1] = Posizione.TORINO;
	nameLookup[2] = Posizione.GENOVA;
	nameLookup[3] = Posizione.BOLOGNA;
	nameLookup[4] = Posizione.VENEZIA;
	Arrays.sort(nameLookup);
	
	milano = Arrays.binarySearch(nameLookup, Posizione.MILANO);
	torino = Arrays.binarySearch(nameLookup, Posizione.TORINO);
	genova = Arrays.binarySearch(nameLookup, Posizione.GENOVA);
	venezia = Arrays.binarySearch(nameLookup, Posizione.VENEZIA);
	bologna=Arrays.binarySearch(nameLookup,Posizione.BOLOGNA);
	

	
	int[][] matrix=new int[5][5];	
	
	matrix[milano][milano] = 0;
	matrix[milano][torino] = 143;
	matrix[milano][genova] = 150;
	matrix[milano][venezia] = 270;
	matrix[milano][bologna] = 216;
	
	matrix[torino][milano] = 143;
	matrix[torino][torino] = 0;
	matrix[torino][genova] = 171;
	matrix[torino][venezia] = 403;
	matrix[torino][bologna] = 332;
	
	matrix[genova][milano] = 150;
	matrix[genova][torino] = 171;
	matrix[genova][genova] = 0;
	matrix[genova][venezia] = 401;
	matrix[genova][bologna] = 296;
	
	matrix[venezia][milano] = 270;
	matrix[venezia][torino] = 403;
	matrix[venezia][genova] = 401;
	matrix[venezia][venezia] = 0;
	matrix[venezia][bologna] = 154;

	matrix[bologna][milano] = 216;
	matrix[bologna][torino] = 403;
	matrix[bologna][genova] = 296;
	matrix[bologna][venezia] = 154;
	matrix[bologna][bologna] =0;
	
	this.matrix=matrix;
}
	
	/**
	 * trova dove si trova attualmente l'auto
	 * @param auto auto da trovare
	 * @return Posizione attuale auto
	 */
	public Posizione trovaPosizione(Auto auto) {
		switch(auto.getStato()) {
		case NONSCHEDULATO:
			return auto.getConcprovenienza();
		case TRASPORTO1:
			return auto.getConclavorazione();
		case INCODA:
			return auto.getConclavorazione();
		case TRASPORTO2:
			return auto.getConcarrivo();
		case FINITO:
			return auto.getConcarrivo();
		default :
			return null;
		
		}
	}
	
	public int getProvenienza(Posizione p) {
		switch(p) {
			case BOLOGNA: 
				return bologna;
			case MILANO :
				return milano;
			case TORINO:
				return torino;
			case VENEZIA:
				return venezia;
			case GENOVA:
				return genova;
			default:
				return -1;
		}
	}
	
	public Posizione getPosizione(int i) {
		if(i==milano)	return Posizione.MILANO;
		if(i==bologna)	return Posizione.BOLOGNA;
		if(i==genova)	return Posizione.GENOVA;
		if(i==torino)	return Posizione.TORINO;
		if(i==venezia)	return Posizione.VENEZIA;
		else return null;
	}
	
	public int[][] getMatrix() {
		return matrix;
	}

	public void setMatrix(int[][] matrix) {
		this.matrix = matrix;
	}

	public int getMilano() {
		return milano;
	}

	public void setMilano(int milano) {
		this.milano = milano;
	}

	public int getTorino() {
		return torino;
	}

	public void setTorino(int torino) {
		this.torino = torino;
	}

	public int getGenova() {
		return genova;
	}

	public void setGenova(int genova) {
		this.genova = genova;
	}

	public int getVenezia() {
		return venezia;
	}

	public void setVenezia(int venezia) {
		this.venezia = venezia;
	}

	public int getBologna() {
		return bologna;
	}

	public void setBologna(int bologna) {
		this.bologna = bologna;
	}

	

}