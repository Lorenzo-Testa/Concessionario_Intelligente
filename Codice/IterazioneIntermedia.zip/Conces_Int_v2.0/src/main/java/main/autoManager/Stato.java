package main.autoManager;

public enum Stato {
	
	NONSCHEDULATO,TRASPORTO1,INLAVORAZIONE,INCODA,TRASPORTO2,FINITO;
		
		
}
