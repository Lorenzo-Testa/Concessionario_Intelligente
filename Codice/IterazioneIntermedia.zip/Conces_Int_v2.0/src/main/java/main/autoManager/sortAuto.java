package main.autoManager;

import java.util.Comparator;

import org.springframework.beans.factory.annotation.Autowired;


public class sortAuto implements Comparator<Auto> {
	


	@Override
	public int compare(Auto o1, Auto o2) {
		
		  // TODO: Handle null x or y values
	    int startComparison = compare(o1.getDataconsegna(), o2.getDataconsegna());
	   
	    return startComparison;
				 
	  }

	
	  private static int compare(String a, String b) {
	    return a.compareTo(b);
	  }
	}