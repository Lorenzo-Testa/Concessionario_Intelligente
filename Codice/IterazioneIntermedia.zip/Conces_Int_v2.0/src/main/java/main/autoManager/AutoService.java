package main.autoManager;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import main.interventi.InterventoService;
import main.officina.OfficinaService;
import main.officina.Posizione;

@Service
public class AutoService{
	

	@Autowired
	private AutoRepository ar;
	@Autowired
	private OfficinaService os;
	@Autowired
	private InterventoService is;
	
	public AutoService(AutoRepository auto) {
		this.ar = auto;
	}


	/**
	 * aggiunge un nuova auto nella tabella
	 * @param nuovaAuto entita da aggiungere
	 * @return entita aggiunta
	 * richiama officinaService.aggiungi --> incrementa di 1 il valore delle auto presenti nell'officina
	 */
	public Auto inserisciAuto(Auto  nuovaAuto) {
		os.aggiungi(nuovaAuto.getConcprovenienza(),0);
		return ar.save(nuovaAuto);
	}


	/**
	 * quando un auto viene comprata l'algoritmo viene lanciato per ottimizzare la consegna
	 * @param targa
	 * @param proprietario
	 * @param datavendita
	 * @param dataconsegna
	 * @param concessionarioconsegna
	 */
	public Auto CompraAuto(String targa, String proprietario, String datavendita, String dataconsegna,Posizione concessionarioconsegna) {
		Optional<Auto> a=ar.findById(targa);
		if (!a.isPresent()) new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
		if(a.get().isVenduta()) new Exception("L'auto è già stata venduta");
		a.get().setDataconsegna(dataconsegna);
		a.get().setDatavendita(datavendita);
		a.get().setVenduta(true);
		a.get().setProprietario(proprietario);
		a.get().setConcarrivo(concessionarioconsegna);
		Auto b=ar.save(a.get());
		return b;
		//TO-DO LANCIA ALGORITMO
	}


	/**
	 * rimuove un auto dalla tabella
	 * @param targa
	 * @param conc
	 * lancia officinaService.rimuovi-->decrementa di 1 il valore delle auto presenti nell'officina
	 */
	public void RimuoviAuto(String targa,Posizione conc) {
		Optional<Auto> a=ar.findById(targa);
		if (!a.isPresent()) new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
		os.rimuovi(conc,0);
		ar.delete(a.get());
	}

	
	/**
	 *chiamata dopo che l'algoritmo finisce di girare.
	 * @param targa per identificare l'auto
	 * @param concessionariolav concessionario in cui verrà lavorata
	 * richiama officinaservice.aggiungi-->incrementa di 1 il valore delle auto presenti nell'offcina di arrivo
	 * richiama officinaservice.rimuovi-->decrementa di 1 il valore delle auto presenti nell'officina di partenza
	 * richiama InterventoService.officinalavorazione-->setta la lavorazione nell'officina stabilita a tutti gli interventi
	 */
	public void ConcessionarioDiLavorazioneAuto(String targa, Posizione concessionariolav) {
		Optional<Auto> a=ar.findById(targa);
		if (!a.isPresent()) new ResponseStatusException(HttpStatus.NOT_FOUND, "l'auto non esiste");
		os.aggiungi(concessionariolav,0);
		os.rimuovi(a.get().getConcprovenienza(),0);
		a.get().setConclavorazione(concessionariolav);
		is.officinaLavorazione(targa, concessionariolav);
		ar.save(a.get());
		
	}


	public void saveAll(List<Auto> a) {
		ar.saveAll(a);
		
	}






	

	

}
