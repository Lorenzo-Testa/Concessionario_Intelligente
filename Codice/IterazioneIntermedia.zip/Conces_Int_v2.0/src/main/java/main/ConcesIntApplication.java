package main;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.batch.BatchAutoConfiguration;

import main.accountManager.UtenteController;
import main.autoManager.AutoController;
import main.autoManager.AutoOggetto;
import main.interventi.InterventoController;
import main.interventi.InterventoOggetto;
import main.interventi.idIntervento;
import main.officina.*;

@SpringBootApplication(exclude = BatchAutoConfiguration.class)
public class ConcesIntApplication implements CommandLineRunner{
	

	@Autowired
	InterventoController ic;
	@Autowired
	AutoController ac;
	@Autowired
	UtenteController uc;
	@Autowired
	OfficinaRepository or;
	
	
	public static void main(String[] args) {
		SpringApplication.run(ConcesIntApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		AutoOggetto auto=new AutoOggetto("targa3","234456","concessionaria","Fiat","Panda",Posizione.TORINO);
		ac.inserisciAuto(auto);
		idIntervento id=new idIntervento("targa3","lavoro");
		InterventoOggetto a= new InterventoOggetto(id,false,100);
		ic.inserisciIntervento(a);
		id=new idIntervento("targa3","lavoro2");
		a= new InterventoOggetto(id,false,200);
		ic.inserisciIntervento(a);
		id=new idIntervento("targa3","lavoro3");
		a= new InterventoOggetto(id,false,300);
		ic.inserisciIntervento(a);
		
		ac.CompraAuto("targa3", "a", "2021-08-21", "2022-02-10", Posizione.MILANO);
		ac.ConcessionarioDiLavorazioneAuto("targa3",Posizione.BOLOGNA);
		
		//OfficinaOggetto oo= new OfficinaOggetto("Bergamo",5,6);
		
		
		
	}
	
	
	

}

