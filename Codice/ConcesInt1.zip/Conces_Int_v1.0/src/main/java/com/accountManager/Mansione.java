package com.accountManager;

public enum Mansione {
	
	MECCANICO, VENDITORE, POST_VENDITA, CAPO_OFFICINA, CAPO_FILIALE, CAPO_FILIALE_CENTRALE ;
	
}
