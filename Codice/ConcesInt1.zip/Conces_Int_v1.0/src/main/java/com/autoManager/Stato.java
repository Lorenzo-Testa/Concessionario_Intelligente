package com.autoManager;

public enum Stato {
		
		LAVORAZIONE, TRASPORTO, CODA,ATTESA ;
		
	
}
